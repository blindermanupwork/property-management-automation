"""
Centralized Configuration Management
===================================

This module provides a centralized configuration system that:
- Manages all file paths relative to project root
- Handles environment variables with sensible defaults
- Ensures cross-platform compatibility
- Automatically creates required directories
"""

import os
import sys
from pathlib import Path
from typing import Optional, Union
from dotenv import load_dotenv


def find_project_root() -> Path:
    """
    Find the project root directory by looking for marker files.
    
    Returns:
        Path to the project root directory
        
    Raises:
        FileNotFoundError: If project root cannot be found
    """
    # Start from this file's location
    current = Path(__file__).parent
    
    # Look for marker files that indicate project root
    marker_files = ['.env', 'VERSION', 'README.md', 'requirements.txt']
    
    # Walk up the directory tree
    while current != current.parent:
        if any((current / marker).exists() for marker in marker_files):
            return current
        current = current.parent
    
    # Fallback: assume we're in src/automation/ and go up 2 levels
    fallback = Path(__file__).parent.parent.parent
    if fallback.exists():
        return fallback
    
    raise FileNotFoundError(
        f"Cannot find project root. Looked for {marker_files} "
        f"starting from {Path(__file__).parent}"
    )


class Config:
    """
    Centralized configuration management for the automation system.
    
    This class handles:
    - Project path resolution
    - Environment variable management
    - Directory creation
    - Cross-platform compatibility
    """
    
    # Find project root automatically
    PROJECT_ROOT = find_project_root()
    
    # Load environment variables
    _env_loaded = False
    
    @classmethod
    def _ensure_env_loaded(cls):
        """Ensure .env file is loaded exactly once"""
        if not cls._env_loaded:
            env_file = cls.PROJECT_ROOT / '.env'
            if env_file.exists():
                load_dotenv(env_file)
            cls._env_loaded = True
    
    # ═══════════════════════════════════════════════════════════════════════════
    # DIRECTORY PATHS (all relative to project root)
    # ═══════════════════════════════════════════════════════════════════════════
    
    @classmethod
    def get_project_root(cls) -> Path:
        """Get the project root directory"""
        return cls.PROJECT_ROOT
    
    @classmethod
    def get_scripts_dir(cls) -> Path:
        """Get scripts directory"""
        return cls.PROJECT_ROOT / "src" / "automation" / "scripts"
    
    @classmethod
    def get_csv_process_dir(cls) -> Path:
        """Get CSV processing directory"""
        return cls.PROJECT_ROOT / "src" / "automation" / "scripts" / "CSV_process"
    
    @classmethod
    def get_csv_done_dir(cls) -> Path:
        """Get CSV completed directory"""
        return cls.PROJECT_ROOT / "src" / "automation" / "scripts" / "CSV_done"
    
    @classmethod
    def get_logs_dir(cls) -> Path:
        """Get logs directory"""
        return cls.PROJECT_ROOT / "src" / "automation" / "logs"
    
    @classmethod
    def get_backups_dir(cls) -> Path:
        """Get backups directory"""
        return cls.PROJECT_ROOT / "backups"
    
    @classmethod
    def get_itripcsv_downloads_dir(cls) -> Path:
        """Get iTrip CSV downloads directory"""
        return cls.PROJECT_ROOT / "src" / "automation" / "scripts" / "CSV_process"
    
    # ═══════════════════════════════════════════════════════════════════════════
    # ENVIRONMENT VARIABLES
    # ═══════════════════════════════════════════════════════════════════════════
    
    @classmethod
    def get_env(cls, key: str, default: Optional[str] = None) -> Optional[str]:
        """
        Get environment variable with optional default.
        
        Args:
            key: Environment variable name
            default: Default value if not found
            
        Returns:
            Environment variable value or default
        """
        cls._ensure_env_loaded()
        return os.getenv(key, default)
    
    @classmethod
    def get_env_bool(cls, key: str, default: bool = False) -> bool:
        """
        Get boolean environment variable.
        
        Args:
            key: Environment variable name
            default: Default value if not found
            
        Returns:
            Boolean value
        """
        cls._ensure_env_loaded()
        value = os.getenv(key)
        if value is None:
            return default
        return value.lower() in ('true', '1', 'yes', 'on')
    
    @classmethod
    def get_env_int(cls, key: str, default: int = 0) -> int:
        """
        Get integer environment variable.
        
        Args:
            key: Environment variable name
            default: Default value if not found
            
        Returns:
            Integer value
        """
        cls._ensure_env_loaded()
        value = os.getenv(key)
        if value is None:
            return default
        try:
            return int(value)
        except ValueError:
            return default
    
    # ═══════════════════════════════════════════════════════════════════════════
    # AIRTABLE CONFIGURATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    @classmethod
    def get_airtable_api_key(cls) -> str:
        """Get Airtable API key"""
        return cls.get_env('AIRTABLE_API_KEY', '')
    
    @classmethod
    def get_airtable_base_id(cls) -> str:
        """Get Airtable base ID (environment-aware)"""
        environment = cls.get_env('ENVIRONMENT', 'development').lower()
        if environment == 'production':
            return cls.get_env('PROD_AIRTABLE_BASE_ID', '')
        else:
            return cls.get_env('AIRTABLE_BASE_ID', '')
    
    @classmethod
    def get_airtable_table_name(cls) -> str:
        """Get Airtable table name"""
        return cls.get_env('AIRTABLE_TABLE_NAME', 'Reservations')
    
    @classmethod
    def get_properties_table_name(cls) -> str:
        """Get Properties table name"""
        return cls.get_env('PROPERTIES_TABLE_NAME', 'Properties')
    
    @classmethod
    def get_ics_feeds_table_name(cls) -> str:
        """Get ICS Feeds table name"""
        return cls.get_env('ICS_FEEDS_TABLE_NAME', 'ICS Feeds')
    
    @classmethod
    def get_automation_table_name(cls) -> str:
        """Get Automation table name"""
        return cls.get_env('AUTOMATION_TABLE_NAME', 'Automation')
    
    # ═══════════════════════════════════════════════════════════════════════════
    # EVOLVE CONFIGURATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    @classmethod
    def get_evolve_username(cls) -> str:
        """Get Evolve username"""
        return cls.get_env('EVOLVE_USERNAME', '')
    
    @classmethod
    def get_evolve_password(cls) -> str:
        """Get Evolve password"""
        return cls.get_env('EVOLVE_PASSWORD', '')
    
    # ═══════════════════════════════════════════════════════════════════════════
    # HOUSECALLPRO CONFIGURATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    @classmethod
    def get_hcp_token(cls) -> str:
        """Get HousecallPro API token"""
        return cls.get_env('HCP_TOKEN', '')
    
    @classmethod
    def get_hcp_api_base(cls) -> str:
        """Get HousecallPro API base URL"""
        return cls.get_env('HCP_API_BASE', 'https://pro.housecallpro.com')
    
    # ═══════════════════════════════════════════════════════════════════════════
    # DATE FILTERING CONFIGURATION
    # ═══════════════════════════════════════════════════════════════════════════
    
    @classmethod
    def get_fetch_months_before(cls) -> int:
        """Get number of months to look back for reservations"""
        return cls.get_env_int('FETCH_RESERVATIONS_MONTHS_BEFORE', 2)
    
    @classmethod
    def get_ignore_blocks_months_away(cls) -> int:
        """Get number of months ahead to ignore blocks"""
        return cls.get_env_int('IGNORE_BLOCKS_MONTHS_AWAY', 6)
    
    @classmethod
    def get_ignore_events_ending_before_today(cls) -> bool:
        """Whether to ignore events that ended before today"""
        return cls.get_env_bool('IGNORE_EVENTS_ENDING_BEFORE_TODAY', False)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # UTILITY METHODS
    # ═══════════════════════════════════════════════════════════════════════════
    
    @classmethod
    def ensure_directories(cls) -> None:
        """
        Create all required directories if they don't exist.
        
        This method should be called at startup to ensure the project
        directory structure is properly initialized.
        """
        directories = [
            cls.get_csv_process_dir(),
            cls.get_csv_done_dir(),
            cls.get_logs_dir(),
            cls.get_backups_dir(),
            cls.get_itripcsv_downloads_dir(),
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
    
    @classmethod
    def add_project_to_path(cls) -> None:
        """
        Add the project root to Python's sys.path if not already present.
        
        This enables imports from anywhere in the project structure.
        """
        project_root_str = str(cls.PROJECT_ROOT)
        if project_root_str not in sys.path:
            sys.path.insert(0, project_root_str)
    
    @classmethod
    def get_script_path(cls, script_path: Union[str, Path]) -> Path:
        """
        Get full path to a script relative to the scripts directory.
        
        Args:
            script_path: Relative path from scripts directory
            
        Returns:
            Full path to the script
        """
        return cls.get_scripts_dir() / script_path
    
    @classmethod
    def get_environment(cls) -> str:
        """Get current environment (production/development)"""
        return cls.get_env('ENVIRONMENT', 'development').lower()
    
    @classmethod
    def is_production(cls) -> bool:
        """Check if running in production environment"""
        return cls.get_environment() == 'production'
    
    @classmethod
    def get_version(cls) -> str:
        """Get project version from VERSION file"""
        version_file = cls.PROJECT_ROOT / 'VERSION'
        if version_file.exists():
            return version_file.read_text().strip()
        return "1.1.0"  # fallback
    
    @classmethod
    def validate_config(cls) -> list:
        """
        Validate configuration and return list of missing required settings.
        
        Returns:
            List of missing configuration keys
        """
        cls._ensure_env_loaded()
        
        required_keys = [
            'AIRTABLE_API_KEY',
        ]
        
        # Add environment-specific requirements
        if cls.is_production():
            required_keys.append('PROD_AIRTABLE_BASE_ID')
        else:
            required_keys.append('AIRTABLE_BASE_ID')
        
        missing = []
        for key in required_keys:
            if not cls.get_env(key):
                missing.append(key)
        
        return missing
    
    # Airtable Field Configuration Methods
    @classmethod
    def get_automation_name_field(cls) -> str:
        """Get automation name field from environment"""
        return cls.get_env("AUTOMATION_NAME_FIELD", "Name")
    
    @classmethod
    def get_automation_active_field(cls) -> str:
        """Get automation active field from environment"""
        return cls.get_env("AUTOMATION_ACTIVE_FIELD", "Active")
    
    @classmethod
    def get_automation_last_ran_field(cls) -> str:
        """Get automation last ran field from environment"""
        return cls.get_env("AUTOMATION_LAST_RAN_FIELD", "Last Ran")
    
    @classmethod
    def get_automation_sync_details_field(cls) -> str:
        """Get automation sync details field from environment"""
        return cls.get_env("AUTOMATION_SYNC_DETAILS_FIELD", "Sync Details")


# Initialize directories on import
Config.ensure_directories()