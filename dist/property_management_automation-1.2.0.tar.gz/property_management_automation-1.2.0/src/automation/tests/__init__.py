"""
Automation Package Test Suite

Tests for the property management automation system.
"""